# Terraform-Demo
Terraform-Demo


#Watch out that app service name is unique.

Error: The name "terraform-app-service" used for the App Service 
needs to be globally unique and isn't available: 
Hostname 'terraform-app-service' already exists. Please select a different name.

